Instructions to run the simulation:

1.	Open Matlab and install the “myapp.mlappinstall” file.
2.	Then run the installed “myapp”.
3.	The GUI Pops up click "Enter DH Table here".
4.	Next tab opens where you can enter the "DH Parameters" and Do all the calculations.

Note: It might take some time to give the Output and to switch other tabs so kindly wait patiently.