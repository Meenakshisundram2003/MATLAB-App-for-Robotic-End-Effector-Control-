function tau = equation_of_motion(dhs, motion_attributes) 
    syms q qd qdd 
     
    [n, ~] = size(motion_attributes); 
     
    % DH parameter constants 
    alpha = dhs(:,1); 
    a = dhs(:,2); 
    d = dhs(:,4); 
     
    % Gravity 
    g0 = [0; 0; 9.81]; 
     
    % Extract motion attributes 
    kr = motion_attributes(:, 1); 
    ml = motion_attributes(:, 2); 
    mm = motion_attributes(:, 3); 
    IL = motion_attributes(:, 4); 
    Im = motion_attributes(:, 5); 
    types = motion_attributes(:, 6); 
 
    % Initialize symbolic variables 
    T = cell(n, 1); 
    R = cell(n, 1); 
    Rm = cell(n, 1); 
    P = sym(zeros(3, n + 1)); 
    z = sym(zeros(3, n)); 
    JpL = cell(n, 1); 
    JoL = cell(n, 1); 
    Jpm = cell(n, 1); 
    Jom = cell(n, 1); 
    B = cell(n, 1); 
    c = cell(n, 1); 
    gg = cell(n, 1); 
     
    % Calculate transformation matrices 
    A1 = eye(4); 
    for i = 1:n 
        A = [cosd(q(i)) -sind(q(i))*cosd(alpha(i))  sind(q(i))*sind(alpha(i)) a(i)*cosd(q(i)); 
             sind(q(i))  cosd(q(i))*cosd(alpha(i)) -cosd(q(i))*sind(alpha(i)) a(i)*sind(q(i)); 
             0               sind(alpha(i))                 cosd(alpha(i))                d(i); 
             0               0                              0                             1]; 
        T{i} = A1 * A; 
        A1 = T{i}; 
        R{i} = A(1:3, 1:3); 
        if i == 1 
            Rm{i} = eye(3); 
        else 
            Rm{i} = R{i-1}; 
        end 
    end 
     
    % Calculate joint positions 
    for i = 1:n+1 
        if i == 1 
            P(:, 1) = [0; 0; 0]; 
        else 
            P(:, i) = T{i-1}(1:3, 4); 
        end 
    end 
     
    % Calculate z axis 
    for i = 1:n 
        z(:, i) = T{i}(1:3, 3); 
    end 
     
    % Calculate Jacobian matrices 
    for i = 1:n 
        JpL{i} = calc_JpL(i, z, P, PL); 
        JoL{i} = calc_JoL(i, z, types); 
        Jpm{i} = calc_Jpm(i, z, P, PL); 
        Jom{i} = calc_Jom(i, kr, z); 
    end 
     
    % Calculate B matrix 
    BB = zeros(n); 
    for i = 1:n 
        B{i} = calc_B(i, ml, JpL, JoL, mm, Jpm, Jom, IL, R, Im, Rm); 
        BB = BB + B{i}; 
    end 
     
    % Calculate Coriolis matrix 
    C = calc_C(n, q, qd, BB); 
     
    % Calculate gravitational forces 
    g1 = calc_g(n, ml, g0, JpL, mm, Jpm); 
     
    % Calculate torques 
    tau = BB * qdd + C * qd + g1; 
end 
 
function JpL = calc_JpL(i, z, P, PL) 
    % Calculate JpL matrix 
    if i == 1 
        JpL = z(:, 1); 
    else 
        JpL = cross(z(:, i), PL{i} - P(:, i)); 
    end 
end 
 
function JoL = calc_JoL(i, z, types) 
    % Calculate JoL matrix 
    switch types(i) 
        case 1 
            JoL = zeros(3, i); 
        otherwise 
            JoL = z(:, 1:i); 
    end 
end 
 
function Jpm = calc_Jpm(i, z, P, PL) 
    % Calculate Jpm matrix 
    if i == 1 
        Jpm = zeros(3, i); 
    else 
        Jpm = zeros(3, i); 
        for j = 1:i-1 
            Jpm(:, j) = cross(z(:, j), PL{i-1} - P(:, j)); 
        end 
    end 
end 
 
function Jom = calc_Jom(i, kr, z) 
    % Calculate Jom matrix 
    Jom = zeros(3, i); 
    for j = 1:i 
        if j == i 
            Jom(:, i) = kr(i) * z(:, i); 
        else 
            Jom(:, j) = zeros(3, 1); 
        end 
    end 
end 
 
function B = calc_B(i, ml, JpL, JoL, mm, Jpm, Jom, IL, R, Im, Rm) 
    % Calculate B matrix 
    B = ml(i) * JpL{i}' * JpL{i} + JoL{i}' * R{i} * IL(i) * R{i}' * JoL{i} ... 
        + mm(i) * Jpm{i}' * Jpm{i} + Jom{i}' * Rm{i} * Im(i) * Rm{i}' * Jom{i}; 
end 
 
function C = calc_C(n, q, qd, BB) 
    % Calculate Coriolis matrix 
    C = sym(zeros(n, n)); 
    for i = 1:n 
        for j = 1:n 
            s = 0; 
            for k = 1:n 
                s = s + 0.5 * (diff(BB(i, j), q(k)) + diff(BB(i, k), q(j)) - diff(BB(j, k), q(i))) * qd(k); 
            end 
            C(i, j) = s; 
        end 
    end 
end 
 
function g1 = calc_g(n, ml, g0, JpL, mm, Jpm) 
    % Calculate gravitational forces 
    g1 = sym(zeros(n, 1)); 
    for i = 1:n 
        s = 0; 
        for j = 1:n 
            s = s + ml(j) * g0'* JpL{j}(:, i) + mm(j) * g0' * Jpm{j}(:, i); 
        end 
        g1(i) = s; 
    end 
end