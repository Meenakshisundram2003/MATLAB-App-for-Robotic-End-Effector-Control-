function impedance(xd1, xd2, K_D, K_P, a1, a2, friction, IL1, IL2, mL1, mL2, mm2, L1, L2, kr1, kr2, Im1, Im2, q1, q2, xd_dot, xd_doubledot, xr, stiffness, mdx, mdy) 
    xd = [xd1, xd2]; 
    qi = [q1, q2]; 
     
    % Run simulation 
    options = simset('SrcWorkspace', 'current', 'DstWorkspace', 'current'); 
    sim('impedance_control_sim', 1, options); 
 
    % Plot desired vs actual end-effector position and contact force 
    plot_results(ans.tout, ans.xe, xd, ans.f); 
end 
 
function plot_results(tout, xe, xd, f) 
    % Plot desired vs actual end-effector position 
    figure('Name', 'Indirect force control through impedance control'); 
 
    % Plot xe vs xd at x-axis 
    subplot(4, 1, 1); 
    plot(tout, xe(:, 1), tout, xd(1) * ones(size(tout))); 
    xlabel('Time (s)'); 
    ylabel('Position (mm)'); 
    title('Desired vs Actual End-Effector at X Direction'); 
    legend('Actual', 'Desired'); 
 
    % Plot xe vs xd at y-axis 
    subplot(4, 1, 2); 
    plot(tout, xe(:, 2), tout, xd(2) * ones(size(tout))); 
    xlabel('Time (s)'); 
    ylabel('Position (mm)'); 
    title('Desired vs Actual End-Effector at Y Direction'); 
    legend('Actual', 'Desired'); 
 
    % Plot end effector contact force 
    subplot(4, 1, 3); 
    plot(tout, f(:, 1)); 
    xlabel('Time (s)'); 
    ylabel('Force (N)'); 
    title('Contact Force at X Direction'); 
 
    subplot(4, 1, 4); 
    plot(tout, f(:, 2)); 
    xlabel('Time (s)'); 
    ylabel('Force (N)'); 
    title('Contact Force at Y Direction'); 
end