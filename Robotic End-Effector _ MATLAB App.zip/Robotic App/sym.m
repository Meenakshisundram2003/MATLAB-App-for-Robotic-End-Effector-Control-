classdef sym < handle & matlab.mixin.CustomCompactDisplayProvider & symbolic.mixin.abstractsize
    %SYM    Construct symbolic numbers, variables and objects.
    %   S = SYM(A) constructs an object S, of class 'sym', from A.
    %   If the input argument is a string, the result is a symbolic number
    %   or variable.  If the input argument is a numeric scalar or matrix,
    %   the result is a symbolic representation of the given numeric values.
    %   If the input is a function handle the result is the symbolic form
    %   of the body of the function handle.
    %
    %   x = sym('x') creates the symbolic variable with name 'x' and stores the
    %   result in x.  x = sym('x','real') also assumes that x is real, so that
    %   conj(x) is equal to x.  alpha = sym('alpha') and r = sym('Rho','real')
    %   are other examples.  Similarly, k = sym('k','positive') makes k a
    %   positive (real) variable.  x = sym('x','clear') restores x to a
    %   formal variable with no additional properties (i.e., insures that x
    %   is NEITHER real NOR positive).
    %   See also: SYMS.
    %
    %   A = sym('A',[N1 N2 ... Nk]) creates an N1-by-N2-...-by-Nk array of
    %   symbolic scalar variables. Elements of vectors have names of the form Ai and elements
    %   of matrices and higher-dimensional arrays have names of the form
    %   Ai1_..._ik where each ij ranges over 1:Nj.
    %   The form can be controlled exactly by using '%d' in the first
    %   input (eg 'A%d%d' will make names Ai1i2).
    %   A = sym('A',N) creates an N-by-N matrix.
    %
    %   Statements like delta = sym('1/10') create symbolic numbers which avoid
    %   the floating point approximations inherent in the value 1/10.
    %
    %   S = sym(A,flag) converts a numeric scalar or matrix to symbolic form.
    %   The technique for converting floating point numbers is specified by
    %   the optional second argument, which may be 'f', 'r', 'e' or 'd'.
    %   The default is 'r'.
    %
    %   'f' stands for 'floating point'.  All values are transformed from
    %   double precision to exact numeric values N*2^e for integers N and e.
    %
    %   'r' stands for 'rational'.  Floating point numbers obtained by
    %   evaluating expressions of the form p/q, p*pi/q, sqrt(p/q), 2^q and 10^q
    %   for modest sized integers p and q are converted to the corresponding
    %   symbolic form.  This effectively compensates for the roundoff error
    %   involved in the original evaluation, but may not represent the floating
    %   point value precisely.  If no simple rational approximation can be
    %   found, the 'f' form is used.
    %
    %   'e' stands for 'estimate error'.  The 'r' form is supplemented by a
    %   term involving the variable 'eps' which estimates the difference
    %   between the theoretical rational expression and its actual floating
    %   point value.  For example, sym(3*pi/4,'e') is 3*pi/4-103*eps/249.
    %
    %   'd' stands for 'decimal'.  The number of digits is taken from the
    %   current setting of DIGITS used by VPA.  Using fewer than 16 digits
    %   reduces accuracy, while more than 16 digits may not be warranted.
    %   For example, with digits(10), sym(4/3,'d') is 1.333333333, while
    %   with digits(20), sym(4/3,'d') is 1.3333333333333332593,
    %   which does not end in a string of 3's, but is an accurate decimal
    %   representation of the double-precision floating point number nearest
    %   to 4/3.
    %
    %   See also SYMS, CLASS, DIGITS, VPA.

    %   Copyright 1993-2023 The MathWorks, Inc.

    properties (Access=protected)
        s            % must be char
        mathmlOutput % caching only   
        Digits       % only guaranteed to be set for saved objects, 
                     % use extractCreationTimeDigits(x) instead
    end
    methods(Static)
        function y = loadobj(x)
            %LOADOBJ    Load symbolic object
            %   Y = LOADOBJ(X) is called when loading symbolic objects

            if isa(x,'struct')
                if isscalar(x)
                    if isfield(x,'digits') && ~isempty(x.digits)
                        oldDigits = digits(x.digits);
                        resetDigits = onCleanup(@() digits(oldDigits));
                    elseif isfield(x,'Digits') && ~isempty(x.Digits)
                        oldDigits = digits(x.Digits);
                        resetDigits = onCleanup(@() digits(oldDigits));
                    end
                    y = evalin2sym(symengine, x.s);
                else
                    y = reshape({x.s},size(x));
                    for i = 1:numel(y)
                        y{i} = evalin2sym(symengine, y{i});
                    end
                    y = cell2sym(y);
                end
            else
                n = builtin('numel',x);
                if n > 1
                    % x is an ndim sym
                    cx = reshape({x.s},size(x));
                    y = cell2sym(cx);
                elseif n == 0
                    y = reshape(sym([]),size(x));
                else
                    y = x;
                end
                if ~isempty(x.Digits)
                    oldDigits = digits(x.Digits);
                    resetDigits = onCleanup(@() digits(oldDigits));
                end
            end
            y2 = feval2sym_NaNsingularity(symengine, 'symobj::normalizeOldObjects',y.s);
            if isa(y,'symfun')
                y = symfun(y2,argnames(y));
            elseif isfield(x,'vars')
                y = symfun(y2,x.vars);
            else
                y = y2;
            end
        end

        function y = zeros(varargin)
            %ZEROS  Symbolic version of the builtin function ZEROS.
            y = sym(zeros(varargin{:}));
        end

        function y = ones(varargin)
            %ONES  Symbolic version of the builtin function ONES.
            y = sym(ones(varargin{:}));
        end

        function y = empty(varargin)
            %EMPTY  Symbolic version of the builtin function EMPTY.
            y = sym(double.empty(varargin{:}));
        end

        function y = inf(varargin)
            %INF  Symbolic version of the builtin function INF.
            y = sym(inf(varargin{:}));
        end

        function y = nan(varargin)
            %NAN  Symbolic version of the builtin function NAN.
            y = sym(nan(varargin{:}));
        end

        function y = eye(varargin)
            %EYE  Symbolic version of the builtin function EYE.
            y = sym(eye(varargin{:}));
        end

        function y = cast(a)
            %CAST  Symbolic version of the builtin function CAST.
            y = sym(a);
        end
    end

    methods(Hidden,Static)
        [eqns,vars] = getEqnsVars(varargin)
        B           = checkIgnoreAnalyticConstraintsValue(v)
        B           = isVariable(x)
        B           = isDistinctVariable(x)
        function B = isMathematicalConstant(x)
            B = any(strcmp(x, constantIdents));
        end
        function B = isNumericString(x)
            % call local method
            B = isNumStr(x);
        end
        B = isCondition(x)
        f = charToFunction(c)
        function res = useSymForNumeric(fn, varargin)
            for i = 1:nargin-1
                if ~isnumeric(varargin{i})
                    error(message('symbolic:symbolic:NonNumericParameter'));
                end
            end
            oldDigits = digits(16);
            args = cellfun(@(x)vpa(x), varargin, UniformOutput = false);
            cleanupObj = onCleanup(@() digits(oldDigits));
            res = fn(args{:});
            try
                res = cast(res,superiorfloat(varargin{:}));
            catch err
                error(message('symbolic:sym:NoDoubleConversion'));
            end
        end
        function B = pathToFullPath(file)
            % file must exist, this is a precondition for using this function
            % The function creates a canonical full path.
            if isstring(file) && isscalar(file)
                file = char(file);
            end
            validateattributes(file, {'char'}, {'row'});
            B = dir(file);
            B = fullfile(B.folder,B.name);
        end
        function B = convertStrings(B)
            l = length(B);
            for k=1:l
                if isstring(B{k}) && isscalar(B{k})
                    B{k} = char(B{k});
                end
            end
        end
        function s = symtrue(varargin)
            if nargin == 0
                s = sym("_symans_fake");
                s.s = 'TRUE';
            else
                s = true(varargin{:}) | sym(1);
            end
        end
        function s = symfalse(varargin)
            if nargin == 0
                s = sym("_symans_fake");
                s.s = 'FALSE';
            else
                s = false(varargin{:}) | sym(0);
            end
        end

        function startTimelineTrace
            evalin2null(symengine,"stdlib::setMWLog(TRUE):");
        end
        function stopTimelineTrace
            evalin2null(symengine,"stdlib::setMWLog(FALSE):");
        end

        %
        % default argument functions
        %
        function x = chooseVar(f)
            %chooseVar returns a variable for the input f according to defaults
            % of vector calculus functions.
            arguments
                f {mustBeA(f, ["sym", "symfun"])}
            end
            if isa(f, 'symfun')
                x = argnames(f);
            else
                x = symvar(f);
            end
        end
    end


    methods
        function S = sym(x, n, a)
            if isstring(x)
                if isscalar(x)
                    if ismissing(x)
                        x = NaN;
                    else
                        x = char(x);
                    end
                else
                    ism = ismissing(x);
                    if any(ism)
                        s = x;
                        x = cell(size(s));
                        x(~ism) = cellstr(s(~ism));
                        x(ism) = {NaN};
                    else
                        x = cellstr(x);
                    end
                end
            elseif ischar(x) && size(x,1) > 1
                x = cellstr(x);
            end
            if nargin == 1
                S.s = tomupad(x);
            elseif nargin == 2
                if isstring(n) && isscalar(n)
                    n = char(n);
                end
                if (isnumeric(x) || islogical(x)) && ischar(n)
                    % n is a flag
                    S.s = numericToMuPAD(x, n);
                elseif strcmp(n,'MuPADunit')
                    S.s = x;
                    return;
                elseif ischar(n) || iscellstr(n) || isstring(n)
                    % n is an assumption
                    % if x is a sym, instead of sym(x, set),
                    % assume(x, set) has to be used
                    if isa(x, 'sym')
                        if nargout == 0
                            ric = matlab.lang.correction.ReplaceIdentifierCorrection('sym', 'assume');
                            error(ric, message('symbolic:sym:sym:UseAssume'));
                        else
                            error(message('symbolic:sym:sym:UseAssume'));
                        end
                    end
                    S.s = tomupad(x);
                    assume(S, n);
                elseif isnumeric(n)
                    % n is a size
                    S.s = charToMuPAD(x, n);
                else
                    error(message('symbolic:sym:SecondInputClass'));
                end
            else  % nargin == 3
                % three arguments
                if ~isnumeric(n)
                    error(message('symbolic:sym:SecondArgumentSizeVector'))
                end
                S.s = charToMuPAD(x, n);
                assume(S, a);
            end
            S = normalizesym(S);
        end % sym constructor

        function delete(h)
            if builtin('numel',h)==1 && ~isempty(h.s)
                addGarbage(symengine, h);
            end
        end

        function y = argnames(~)
            %ARGNAMES   Symbolic function input variables
            %   ARGNAMES(F) returns a sym array [X1, X2, ... ] of symbolic
            %   variables for F(X1, X2, ...).
            y = sym([]);
        end

        function x = formula(x)
            %FORMULA   Symbolic function formula body
            %   FORMULA(F) returns the definition of symbolic
            %   function F as a sym object expression.
            %
            %   FORMULA is a no-op on a sym.
            %   See SYMFUN/FORMULA for the nontrivial operation.
            %
            %   See also SYMFUN/ARGNAMES, SYMFUN/FORMULA
        end

        function y = length(x)
            %LENGTH   Length of symbolic vector.
            %   LENGTH(X) returns the length of vector X.  It is equivalent
            %   to MAX(SIZE(X)) for non-empty arrays and 0 for empty ones.
            %
            %   See also NUMEL.
            xsym = privResolveArgs(x);
            x = xsym{1};
            sz = size(x);
            if prod(sz)==0
                y = 0;
            else
                y = max(sz);
            end
        end

        %---------------   Arithmetic  -----------------
        function Y = uminus(X)
            %UMINUS Symbolic negation.
            Y = privUnaryOp(X, 'symobj::map', '_negate');
        end

        function Y = uplus(X)
            %UPLUS Unary plus.
            Xsym = privResolveArgs(X);
            X = Xsym{1};
            Y = X;
        end

        function X = times(A, B)
            %TIMES  Symbolic array multiplication.
            %   TIMES(A,B) overloads symbolic A .* B.
            X = privBinaryOp(A, B, 'symobj::zipWithImplicitExpansion', '_mult');
        end

        function X = mtimes(A, B)
            %TIMES  Symbolic matrix multiplication.
            %   MTIMES(A,B) overloads symbolic A * B.
            X = privBinaryOp(A, B, 'symobj::mtimes');
        end

        function B = mpower(A,p)
            %POWER  Symbolic matrix power.
            %   POWER(A,p) overloads symbolic A^p.
            %
            %   Example;
            %      A = [x y; alpha 2]
            %      A^2 returns [x^2+alpha*y  x*y+2*y; alpha*x+2*alpha  alpha*y+4].
            B = privBinaryOp(A, p, 'symobj::mpower');
        end

        function B = power(A,p)
            %POWER  Symbolic array power.
            %   POWER(A,p) overloads symbolic A.^p.
            %
            %   Examples:
            %      A = [x 10 y; alpha 2 5];
            %      A .^ 2 returns [x^2 100 y^2; alpha^2 4 25].
            %      A .^ x returns [x^x 10^x y^x; alpha^x 2^x 5^x].
            %      A .^ A returns [x^x 1.0000e+10 y^y; alpha^alpha 4 3125].
            %      A .^ [1 2 3; 4 5 6] returns [x 100 y^3; alpha^4 32 15625].
            %      A .^ magic(3) is an error.
            B = privBinaryOp(A, p, 'symobj::zipWithImplicitExpansion', '_power');
        end

        function X = rdivide(A, B)
            %RDIVIDE Symbolic array right division.
            %   RDIVIDE(A,B) overloads symbolic A ./ B.
            %
            %   See also SYM/LDIVIDE, SYM/MRDIVIDE, SYM/MLDIVIDE, SYM/QUOREM.
            X = privBinaryOp(A, B, 'symobj::zipWithImplicitExpansion', 'symobj::divide');
        end

        function X = ldivide(A, B)
            %LDIVIDE Symbolic array left division.
            %   LDIVIDE(A,B) overloads symbolic A .\ B.
            %
            %   See also SYM/RDIVIDE, SYM/MRDIVIDE, SYM/MLDIVIDE, SYM/QUOREM.
            X = privBinaryOp(B, A, 'symobj::zipWithImplicitExpansion', 'symobj::divide');
        end

        function X = mrdivide(A, B)
            %/  Slash or symbolic right matrix divide.
            %   A/B is the matrix division of B into A, which is roughly the
            %   same as A*INV(B) , except it is computed in a different way.
            %   More precisely, A/B = (B'\A')'. See SYM/MLDIVIDE for details.
            %   Warning messages are produced if X does not exist or is not unique.
            %   Rectangular matrices A are allowed, but the equations must be
            %   consistent; a least squares solution is not computed.
            %
            %   See also SYM/MLDIVIDE, SYM/RDIVIDE, SYM/LDIVIDE, SYM/QUOREM.
            X = privBinaryOp(A, B, 'symobj::mrdivide');
        end

        function X = mldivide(A, B)
            %MLDIVIDE Symbolic matrix left division.
            %   MLDIVIDE(A,B) overloads symbolic A \ B.
            %   X = A\B solves the symbolic linear equations A*X = B.
            %   Warning messages are produced if X does not exist or is not unique.
            %   Rectangular matrices A are allowed, but the equations must be
            %   consistent; a least squares solution is not computed.
            %
            %   See also SYM/MRDIVIDE, SYM/LDIVIDE, SYM/RDIVIDE, SYM/QUOREM.
            X = privBinaryOp(A, B, 'symobj::mldivide');
        end

        %---------------   Logical Operators    -----------------

        function X = eq(A, B)
            %EQ     Symbolic equality test.
            %   EQ(A,B) overloads symbolic A == B. If A and B are integers,
            %   rational numbers, floating point values or complex numbers
            %   then A == B compares the values and returns true or false.
            %   Otherwise A == B returns a sym object of the unevaluated equation
            %   which can be passed to other functions like solve. To force
            %   the equation to perform a comparison call LOGICAL or isAlways.
            %   LOGICAL will compare the two sides structurally. isAlways will
            %   compare the two sides mathematically.
            %
            %   See also SYM/LOGICAL, SYM/isAlways
            try
                X = privComparison(A, B, '_equal', 'FALSE', 'FALSE');
            catch
                resSize = size(A);
                if isscalar(A)
                    resSize = size(B);
                elseif ~isscalar(B) && ~isequal(size(A), size(B))
                    error(message('MATLAB:dimagree'));
                end
                X = sym(zeros(resSize)) == sym(ones(resSize));
            end
        end

        function X = ne(A, B)
            %NE     Symbolic inequality test.
            %   NE(A,B) overloads symbolic A ~= B.  The result is the opposite of
            %   A == B.
            X = privComparison(A, B, '_unequal', 'FALSE', 'TRUE');
        end

        function X = logical(A)
            %LOGICAL     Convert symbolic expression to logical array
            %   X = LOGICAL(A) converts each element of the symbolic
            %   array X into the value true or false.
            %   Symbolic equations are converted to true
            %   only if the left and right sides are identically
            %   the same. Otherwise the equation is converted to
            %   false. Inequalities which cannot be proved will
            %   throw an error. NaN throws an error.
            %
            %   See also: sym/isAlways
            if A.s == "TRUE"
                X = true;
                return
            end
            if A.s == "FALSE"
                X = false;
                return
            end
            try
                X = feval2logical(symengine, 'symobj::logical', A.s);
            catch err
                throw(err);
            end
        end

        function X = all(A, dim)
            %ALL     True if all symbolic values are true
            if nargin==1
                X = all(logicalNaNIsTrue(A));
            elseif isa(dim, 'sym')
                X = all(logicalNaNIsTrue(A), double(dim));
            elseif isstring(dim)
                X = all(logicalNaNIsTrue(A), char(dim));
            else
                X = all(logicalNaNIsTrue(A), dim);
            end
        end
        function varargout = find(A,varargin)
            %FIND    Find non-zero elements of symbolic arrays
            narginchk(1, 3);
            if nargin == 3
                try
                    varargin{2} = validatestring(varargin{2}, {'first','last'});
                catch err
                    error(message('MATLAB:find:InputClass'));
                end
            end
            if ~isa(A, 'sym')
                varargin{1} = double(varargin{1});
                [varargout{1:nargout}] = find(A, varargin{:});
                return
            end
            B = feval2logical(symengine, 'symobj::find', A.s);
            if nargout == 3
                [i,j] = find(B,varargin{:});
                c = sym(i);
                if isscalar(formula(A))
                    if ~isempty(c)
                        c = formula(A);
                    end
                else
                    for k = 1:length(i)
                        c = privsubsasgn(c, privTrinaryOp(A, i(k), j(k), '_index'), k);
                    end
                end
                varargout{1} = i;
                varargout{2} = j;
                varargout{3} = c;
            else
                [varargout{1:nargout}] = find(B,varargin{:});
            end
        end

        function X = any(A, dim)
            %ANY     True if any symbolic value is true
            if nargin==1
                X = any(logicalNaNIsFalse(A));
            elseif isa(dim, 'sym')
                X = any(logicalNaNIsFalse(A), double(dim));
            elseif isstring(dim)
                X = any(logicalNaNIsFalse(A), char(dim));
            else
                X = any(logicalNaNIsFalse(A), dim);
            end
        end

        function c = isequal(a,b,varargin)
            %ISEQUAL     Symbolic isequal test.
            %   ISEQUAL(A,B) returns true iff A and B are identical.
            if ~isa(a, 'sym') || ~isa(b, 'sym')
                c = false;
            else
                args = privResolveArgs(a, b, varargin{:});
                c = feval2logicalCast(symengine, 'symobj::isequal', args{1}.s, args{2}.s);
            end
            if c && nargin > 2
                c = isequal(b,varargin{:});
            end
        end

        function c = isequaln(a,b,varargin)
            %ISEQUALN     Symbolic isequaln test.
            %   ISEQUALN(A,B) returns true iff A and B are identical
            %   treating NaNs as equal.
            if ~isa(a, 'sym') || ~isa(b, 'sym')
                c = false;
            else
                args = privResolveArgs(a, b, varargin{:});
                c = feval2logicalCast(symengine, 'symobj::isequaln', args{1}.s, args{2}.s);
            end
            if c && nargin > 2
                c = isequaln(b,varargin{:});
            end
        end

        function X = gt(A,B)
            %GT     Symbolic greater-than.
            X = privComparison(B, A, '_less', 'TRUE', 'FALSE');
        end

        function X = lt(A,B)
            %LT     Symbolic less-than.
            X = privComparison(A, B, '_less', 'TRUE', 'FALSE');
        end

        function X = ge(A,B)
            %GE     Symbolic greater-than-or-equal.
            X = privComparison(B, A, '_leequal', 'TRUE', 'FALSE');
        end

        function X = le(A,B)
            %LE     Symbolic less-than-or-equal.
            X = privComparison(A, B, '_leequal', 'TRUE', 'FALSE');
        end

        function assume(cond,set)
            %ASSUME Assume symbolic relationship.
            %   ASSUME(COND) sets the condition COND to be true. When you
            %   set an assumption, the toolbox replaces any previous
            %   assumptions on the free variables in COND with the new
            %   assumption.
            %   ASSUME(X,SET) assumes the variable X is in the specified
            %   set. Specify SET as 'integer','rational', 'real', or 'positive'.
            %   ASSUME(X, {SET1, ...}) assumes the variable X is in all
            %   of the specified sets.
            %   ASSUME(X,'CLEAR') removes the assumptions on X.
            %
            %
            %   Example
            %     syms x
            %     assume(x > 1)
            %     isAlways(sqrt(x^2) > 1)     % returns true
            %     assume(x,'clear')           % removes assumptions
            %
            %   See also SYM, SYM/assumeAlso, ASSUMPTIONS.
            if nargin == 2
                set = convertCharsToStrings(set);
                if isscalar(set)
                    S = validatestring(set, ["integer", "rational", "real", "positive", "clear"]);
                    if strcmp(S, "clear")
                        feval2sym_NaNsingularity(symengine, 'unassume', cond);
                        return;
                    end
                elseif isempty(set)
                    % edge case: empty set of assumptions
                    feval2sym_NaNsingularity(symengine, 'unassume', cond);
                    return;
                else
                    S = arrayfun(@(X) validatestring(X, ["integer", "rational", "real", "positive"]), set);
                end

                mset = setToMuPADSet(S);
                feval2null(symengine, 'assume', cond, mset);
            else
                feval2null(symengine, 'assume', cond);
            end
            if ~isempty(cond) && isempty(symvar(cond))
                warning(message('symbolic:sym:sym:AssumptionsOnConstantsIgnored'));
            end
        end

        function assumeAlso(cond,set)
            %assumeAlso Add symbolic assumption.
            %   assumeAlso(COND) sets the condition COND to be true
            %   in addition to all previous assumptions.
            %   assumeAlso(X,SET) assumes the variable X is in the specified
            %   set. Specify SET as 'integer','rational', 'real', or 'positive'.
            %   assumeAlso(X, {SET1, ...}) assumes the variable X is in all
            %   of the specified sets.
            %
            %   Example
            %     syms x y
            %     assume(x < y)
            %     assumeAlso(x > 0)
            %     isAlways(x^2 <= y^2)  % returns true
            %     assume([x,y],'clear') % removes assumptions
            %
            %   See also SYM, SYM/ASSUME, ASSUMPTIONS.
            if nargin == 2
                if isempty(set)
                    % edge case: empty set of additional assumptions
                    return;
                end
                mset = setToMuPADSet(set);
                feval2null(symengine, 'assumeAlso', cond, mset);
            else
                feval2null(symengine, 'assumeAlso', cond);
            end
            if ~isempty(cond) && isempty(symvar(cond))
                warning(message('symbolic:sym:sym:AssumptionsOnConstantsIgnored'));
            end
        end

        function X = and(A,B)
            %AND     Symbolic & (and).
            X = privBinaryOp(A, B, 'symobj::zipWithImplicitExpansion', 'symobj::_and');
        end

        function X = or(A,B)
            %OR     Symbolic | (or).
            X = privBinaryOp(A, B, 'symobj::zipWithImplicitExpansion', 'symobj::_or');
        end

        function X = xor(A,B)
            %XOR     Symbolic exclusive-or.
            X = privBinaryOp(A, B, 'symobj::zipWithImplicitExpansion', 'symobj::_xor');
        end

        function X = not(A)
            %NOT     Symbolic ~ (not).
            X = privUnaryOp(A, 'symobj::map', '_not');
        end

        function r = isreal(x)
            %ISREAL True for real symbolic array
            %   ISREAL(X) returns true if X equals conj(X) and false otherwise.
            r = isequaln(x,conj(x));
        end

        function y = isscalar(x)
            %ISSCALAR True if symbolic array is a scalar
            %   ISSCALAR(S) returns logical true (1) if S is a 1 x 1 symbolic matrix
            %   and logical false (0) otherwise.
            xsym = privResolveArgs(x);
            x = xsym{1};
            y = feval2logicalCast(symengine, "isscalar", x);
        end

        function y = isempty(x)
            %ISEMPTY True for empty symbolic array
            %   ISEMPTY(X) returns 1 if X is an empty array and 0 otherwise. An
            %   empty array has no elements, that is prod(size(X))==0.
            xsym = privResolveArgs(x);
            x = xsym{1};
            y = numel(x)==0;
        end

        function r = ismissing(x)
            %ISMISSING False for symbolic array
            %   ISMISSING(X) returns false for all symbolic objects.
            r = false(size(x));
        end

        function r = allfinite(x)
            %ALLFINITE  True if every element of an array is finite.
            %   allfinite(X) returns true if all the elements of X are finite and
            %   false otherwise.
            r = logical(feval2sym_NaNsingularity(symengine, 'symobj::allfinite', x));
        end

        %---------------   Conversions  -----------------

        function X = double(S)
            %DOUBLE Converts symbolic matrix to MATLAB double.
            %   DOUBLE(S) converts the symbolic matrix S to a matrix of double
            %   precision floating point numbers.  S must not contain any symbolic
            %   variables, except 'eps'.
            %
            %   See also SYM, VPA.
            siz = size(formula(S));
            Xstr = feval2char(symengine, "symobj::double", S);
            X = eval(Xstr(2:end-1)); % drop quotes
            if prod(siz) ~= 1
                X = reshape(X,siz);
            end
        end

        function g = inline(f,varargin)
            %INLINE Generate an inline object from a sym object
            %
            %     INLINE will be removed in a future release. Use anonymous
            %     functions instead.
            %
            %     G = INLINE(F) generates an inline object G from the symbolic
            %     expression F using the matlabFunction sym method.
            %
            %     See also: matlabFunction

            f = sym(f);
            func = matlabFunction(f);
            c = func2str(func);
            paren = find(c==')',1);
            g = inline(c(paren+1:end),varargin{:}); %#ok<DINLN>
        end

        function S = single(X)
            %SINGLE Converts symbolic matrix to single precision.
            %   SINGLE(S) converts the symbolic matrix S to a matrix of single
            %   precision floating point numbers.  S must not contain any symbolic
            %   variables, except 'eps'.
            %
            %   See also SYM, SYM/VPA, SYM/DOUBLE, SYM/HALF.
            S = single(double(X));
        end

        function X = half(S)
            %HALF Converts symbolic matrix to half precision.
            %   HALF(S) converts the symbolic matrix S to a matrix of half
            %   precision floating point numbers.  S must not contain any symbolic
            %   variables, except 'eps'.
            %
            %   See also SYM, SYM/VPA, SYM/DOUBLE, SYM/SINGLE.
            X = half(double(S));
        end

        function Y = int8(X)
            %INT8 Converts symbolic matrix to signed 8-bit integers.
            %   INT8(S) converts a symbolic matrix S to a matrix of
            %   signed 8-bit integers.
            %
            %   See also SYM, VPA, SINGLE, DOUBLE,
            %   INT16, INT32, INT64, UINT8, UINT16, UINT32, UINT64.
            Y = int8(int64(X));
        end

        function Y = int16(X)
            %INT16 Converts symbolic matrix to signed 16-bit integers.
            %   INT16(S) converts a symbolic matrix S to a matrix of
            %   signed 16-bit integers.
            %
            %   See also SYM, VPA, SINGLE, DOUBLE,
            %   INT8, INT32, INT64, UINT8, UINT16, UINT32, UINT64.
            Y = int16(int64(X));
        end

        function Y = int32(X)
            %INT32 Converts symbolic matrix to signed 32-bit integers.
            %   INT32(S) converts a symbolic matrix S to a matrix of
            %   signed 32-bit integers.
            %
            %   See also SYM, VPA, SINGLE, DOUBLE,
            %   INT8, INT16, INT64, UINT8, UINT16, UINT32, UINT64.
            Y = int32(int64(X));
        end

        function Y = int64(X)
            %INT64 Converts symbolic matrix to signed 64-bit integers.
            %   INT64(S) converts a symbolic matrix S to a matrix of
            %   signed 64-bit integers.
            %
            %   See also SYM, VPA, SINGLE, DOUBLE,
            %   INT8, INT16, INT32, UINT8, UINT16, UINT32, UINT64.
            Xsym = privResolveArgs(X);
            X = Xsym{1};
            siz = size(formula(X));
            Xd = feval2sym_NaNsingularity(symengine, "(eval@text2expr@symobj::double)", X);
            Xstr = feval2char(symengine, "symobj::map", Xd, "round");
            Y = eval(regexprep(Xstr,'(([-0-9a-zA-Z+*]\s*)+)','int64($1)'));
            Y = int64(Y); % for empty
            if prod(siz) ~= 1
                Y = reshape(Y,siz);
            end
        end

        function Y = uint8(X)
            %UINT8 Converts symbolic matrix to unsigned 8-bit integers.
            %   UINT8(S) converts a symbolic matrix S to a matrix of
            %   unsigned 8-bit integers.
            %
            %   See also SYM, VPA, SINGLE, DOUBLE,
            %   INT8, INT16, INT32, INT64, UINT16, UINT32, UINT64.
            Y = uint8(uint64(X));
        end

        function Y = uint16(X)
            %UINT16 Converts symbolic matrix to unsigned 16-bit integers.
            %   UINT16(S) converts a symbolic matrix S to a matrix of
            %   unsigned 16-bit integers.
            %
            %   See also SYM, VPA, SINGLE, DOUBLE,
            %   INT8, INT16, INT32, INT64, UINT8, UINT32, UINT64.
            Y = uint16(uint64(X));
        end

        function Y = uint32(X)
            %UINT32 Converts symbolic matrix to unsigned 32-bit integers.
            %   UINT32(S) converts a symbolic matrix S to a matrix of
            %   unsigned 32-bit integers.
            %
            %   See also SYM, VPA, SINGLE, DOUBLE,
            %   INT8, INT16, INT32, INT64, UINT8, UINT16, UINT64.
            Y = uint32(uint64(X));
        end

        function Y = uint64(X)
            %UINT64 Converts symbolic matrix to unsigned 64-bit integers.
            %   UINT64(S) converts a symbolic matrix S to a matrix of
            %   unsigned 64-bit integers.
            %
            %   See also SYM, VPA, SINGLE, DOUBLE,
            %   INT8, INT16, INT32, INT64, UINT8, UINT16, UINT32.
            Xsym = privResolveArgs(X);
            X = Xsym{1};
            siz = size(formula(X));
            Xd = feval2sym_NaNsingularity(symengine, '(eval@text2expr@symobj::double)', X.s);
            Xstr = feval2char(symengine, "symobj::map", Xd, "round");
            Y = eval(regexprep(Xstr,'(([-0-9a-zA-Z+*]\s*)+)','uint64($1)'));
            Y = uint64(Y); % for empty
            if prod(siz) ~= 1
                Y = reshape(Y,siz);
            end
        end

        function Y = full(X)
            %FULL Create non-sparse array
            %   Y = FULL(X) creates a full symbolic array from X.
            Y = X;
        end

    end % public methods

    methods(Hidden=true)

        %---------------   Indexing  -----------------

        function X = subsindex(A)
            %SUBSINDEX Symbolic subsindex function
            kind = feval2char(symengine, "symobj::subsindex",A);
            if kind(2) == 'L'
                X = find(feval2logical(symengine, 'symobj::logical', A.s)) - 1;
            elseif kind(2) == 'D' || isempty(A)
                X = double(A) - 1;
            else
                error(message('symbolic:sym:subscript:InvalidIndexOrFunction'));
            end
        end

        function B = subsref(L,Idx)
            %SUBSREF Subscripted reference for a sym array.
            %     B = SUBSREF(A,S) is called for the syntax A(I).  S is a structure array
            %     with the fields:
            %         type -- string containing '()' specifying the subscript type.
            %                 Only parenthesis subscripting is allowed.
            %         subs -- Cell array or string containing the actual subscripts.
            %
            %   See also SYM.
            if ~isempty(Idx) && ~isscalar(Idx)
                error(message('symbolic:sym:NestedIndex'));
            end
            warnNonInteger = false; % for consistency, no warning for A(-1.5)
            if strcmp(Idx.type,'()') && ~isempty(Idx.subs) && ...
                    (isa(Idx.subs{1}, 'double') || isa(Idx.subs{1}, 'single'))
                subsval = round(Idx.subs{1});
                if ~isequal(subsval, Idx.subs{1})
                    warnNonInteger = true;
                    Idx.subs{1} = subsval;
                end
            end
            % special case shortcut for L(:)
            if strcmp(Idx.type,'()') && isscalar(Idx.subs) && ...
                    ischar(Idx.subs{1}) && strcmp(Idx.subs{1},':')
                B = reshape(L,[],1);
                return;
            end
            % shortcut for simple indexing
            R_tilde = Inf;
            if strcmp(Idx.type,'()') && ~isempty(Idx.subs) && ...
                    all(cellfun(@(x) isscalar(x) && isnumeric(x) && ...
                    x==round(x) && isfinite(x) && x > 0, Idx.subs))
                if isscalar(Idx.subs)
                    R_tilde = Idx.subs{1};
                else
                    R_tilde = sub2ind(size(L), Idx.subs{:});
                end
            end
            if R_tilde > numel(L)
                L_tilde = reshape(1:numel(L),size(L));
                R_tilde = builtin('subsref',L_tilde,Idx);
            end
            B = feval2sym_NaNsingularity(symengine, 'symobj::subsref',L.s,privformat(R_tilde));
            if warnNonInteger
                warning(message('MATLAB:colon:nonIntegerIndex'));
            end
        end

        function y = end(x,varargin)
            %END Last index in an indexing expression for a sym array.
            %   END(A,K,N) is called for indexing expressions involving the sym
            %   array A when END is part of the K-th index out of N indices.  For example,
            %   the expression A(end-1,:) calls A's END method with END(A,1,2).
            %
            %   See also SYM.
            xsym = privResolveArgs(x);
            x = xsym{1};
            sz = size(x);
            k = varargin{1};
            n = varargin{2};
            if n < length(sz) && k==n
                sz(n) = prod(sz(n:end));
            end
            if n > length(sz)
                sz = [sz ones(1, n-length(sz))];
            end
            y = sz(k);
        end

        function C = subsasgn(L,Idx,R)
            %SUBSASGN Subscripted assignment for a sym array.
            %     C = SUBSASGN(L,Idx,R) is called for the syntax L(Idx)=R.  Idx is a structure
            %     array with the fields:
            %         type -- string containing '()' specifying the subscript type.
            %                 Only parenthesis subscripting is allowed.
            %         subs -- Cell array or string containing the actual subscripts.
            %
            %   See also SYM.
            if ~isempty(Idx) && ~isscalar(Idx)
                error(message('symbolic:sym:NestedIndex'));
            end
            if ~strcmp(Idx.type,'()')
                error(message('symbolic:sym:InvalidIndexingAssignment'));
            end
            inds = Idx.subs;
            warnNonInteger = false; % for consistency, no warning for A(-1.5)
            dosubs = false;
            for k=1:length(inds)
                if isa(inds{k}, 'double') || isa(inds{k}, 'single')
                    inds_round = round(inds{k});
                    if ~isequal(inds_round, inds{k})
                        warnNonInteger = true;
                        inds{k} = inds_round;
                    end
                end
                if isa(inds{k}, 'symfun') || isempty(inds{k}) || ~isAllVars(inds{k})
                    dosubs = true;
                end
            end
            if dosubs
                if isa(L, 'symfun')
                    error(message('symbolic:sym:subscript:InvalidIndexOrFunction'));
                end
                C = privsubsasgn(L,R,inds{:});
            else
                C = symfun(sym(R),[inds{:}]);
            end
            if warnNonInteger
                warning(message('MATLAB:colon:nonIntegerIndex'));
            end
        end

        function argout = privResolveArgs(varargin)
            argout = varargin;
            n = nargin;
            for k=1:n
                arg = varargin{k};
                if ~isa(arg,'sym')
                    argout{k} = sym(arg);
                end
            end
        end

        function C = privResolveOutput(C,~)
        end

        function C = privResolveOutputAndDelete(C,~,~)
        end

        function C = privQuaternaryOp(A,B,C,D,op,varargin)
            args = privResolveArgs(A, B, C, D);
            try
                Csym = feval2sym(symengine, op,args{1}.s, args{2}.s, args{3}.s, args{4}.s, varargin{:});
            catch err
                throwAsCaller(err);
            end
            C = privResolveOutput(Csym, args{1});
        end

        function C = privTrinaryOp(A,B,C,op,varargin)
            args = privResolveArgs(A, B, C);
            try
                Csym = feval2sym(symengine, op,args{1}.s, args{2}.s, args{3}.s, varargin{:});
            catch err
                throwAsCaller(err);
            end
            C = privResolveOutput(Csym, args{1});
        end

        function C = privBinaryOp(A,B,op,varargin)
            args = privResolveArgs(A, B);
            try
                Csym = feval2sym(symengine, op,args{1}.s, args{2}.s, varargin{:});
            catch err
                throwAsCaller(err);
            end
            C = privResolveOutput(Csym, args{1});
        end

        function B = privUnaryOp(A,op,varargin)
            args = privResolveArgs(A);
            try
                Csym = feval2sym(symengine, op,args{1}.s,varargin{:});
            catch err
                throwAsCaller(err);
            end
            B = privResolveOutput(Csym,A);
        end

        function X = privComparison(A,B,op,project,flipnan)
            args = privResolveArgs(A, B);
            Xsym = feval2sym_NaNsingularity(symengine, 'symobj::eq', args{1}.s, args{2}.s, ...
                op, project, flipnan);
            X = privResolveOutput(Xsym, args{1});
        end

        function M = charcmd(A)
            %CHARCMD   Convert scalar or array sym to string command form
            %   CHARCMD(A) converts A to its string representation for sending commands
            %   to the symbolic engine.
            M = A.s;
        end

        function B = privsubsref(L,varargin)
            %PRIVSUBSREF Private access to subsref
            %   Y = PRIVSUBSREF(X,I1,I2,...) returns the subsref X(I1,I2,..). Methods
            %   in the sym class can call this to avoid calling the builtin subsref.
            L = formula(L);
            % shortcut for simple indexing
            R_tilde = Inf;
            if all(cellfun(@(x) isscalar(x) && isnumeric(x) && ...
                    x==round(x) && isfinite(x) && x > 0, varargin))
                if isscalar(varargin)
                    R_tilde = varargin{1};
                else
                    R_tilde = sub2ind(size(L), varargin{:});
                end
            end
            if R_tilde > numel(L)
                L_tilde = reshape(1:numel(L),size(L));
                R_tilde = builtin('subsref',L_tilde,struct('type','()','subs',{varargin}));
            end
            B = feval2sym_NaNsingularity(symengine, 'symobj::subsref',L.s,privformat(R_tilde));
        end

        function C = privsubsasgn(L, R, varargin)
            %PRIVSUBSASGN Private access to subsasgn
            %   Y = PRIVSUBSASGN(X,B,I1,I2,...) returns the subsasgn X(I1,I2,..)=B. Methods
            %   in the sym class can call this to avoid calling the builtin subsasgn.
            if ~isa(L,'sym')
                L = sym(L);
            end
            isDeleting = builtin('_isEmptySqrBrktLiteral',R);
            % special case: empty index but NOT 'isDeleting'
            if ~isDeleting && isscalar(varargin) && isempty(varargin{1})
                C = L;
                return;
            end
            % special case: replacing empty in empty and NOT 'isDeleting'
            if ~isDeleting && isempty(L) && isempty(R) 
                C = L;
                return;
            end
            if ~isa(R,'sym')
               R = sym(R);
            end
            % sL = size(L);
            sL = feval2double(symengine, 'symobj::size', L.s);
            % sR = size(R);
            sR = feval2double(symengine, 'symobj::size', R.s);
            % shortcut for the most frequent case, A(2,2)=7, for performance reasons:
            if prod(sR) == 1 && ...
                    numel(sL) == numel(varargin) && ...
                    all(cellfun(@isnumeric, varargin)) && ...
                    all(cellfun(@isscalar, varargin)) && ...
                    all(cellfun(@isfinite, varargin)) && ...
                    all([varargin{:}] <= sL)
                inds = sub2ind(sL, varargin{:});
                new_size = strrep(mat2str(sL),' ',',');
                assign_pos = privformat([inds,-1]);
            else
                L_tilde = reshape(1:prod(sL),sL);
                R_tilde = -reshape(1:prod(sR),sR);
                % special cases: 'subsasgn' does not react to all dimension
                % mismatches with an error when right-hand side is empty.
                if prod(sR) == 0 && ~isDeleting
                  % error if dimension of index is not zero
                  if ~isscalar(varargin)
                      error(message('MATLAB:subsassigndimmismatch'));
                  end
                  % error if single index is not empty
                  if isscalar(varargin) && ~isempty(varargin{1}) && ~isa(varargin{1},'sym')
                     error(message('MATLAB:matrix:singleSubscriptNumelMismatch'));
                  end
                end
                L_tilde2 = builtin('subsasgn',L_tilde,struct('type','()','subs',{varargin}),R_tilde);
                % special case: empty lhs
                if numel(L_tilde2) == 0
                    C = sym(L_tilde2);
                    return;
                end
                % special case: no change when deleting with non-empty index
                % Note that d = [0 3; 2 -4]; d(double.empty) = [] => [0 2 3 -4].
                if isDeleting && numel(L_tilde) == numel(L_tilde2) && isscalar(varargin) && ~isempty(varargin{1})
                     C = L; % sym(L);
                     return;
                end
                % prep for sym substitution
                new_size = strrep(mat2str(size(L_tilde2)),' ',',');
                % extract sparse pattern of what we need to assign
                if ~isequal(ndims(L_tilde), ndims(L_tilde2))
                    % we need to transmit all positions to assign to
                    inds = 1:numel(L_tilde2);
                else
                    if ~isequal(size(L_tilde), size(L_tilde2))
                        % we're interested in the part of L_tilde that has the same size as L_tilde2
                        % enlarge far enough that we can safely extract that:
                        out_pos = num2cell(size(L_tilde2) + 1); % we're not going to look there
                        L_tilde(out_pos{:}) = 0;
                        sub_part = num2cell([size(L_tilde2), ones(ndims(L_tilde)-ndims(L_tilde2))]);
                        sub_part = cellfun(@(n) 1:n,sub_part,UniformOutput = false);
                        L_tilde = L_tilde(sub_part{:});
                    end
                    inds = find(L_tilde2 ~= L_tilde);
                    L_tilde2 = L_tilde2(inds);
                end
                assign_pos = privformat([inds(:),L_tilde2(:)]);
            end
            if isempty(inds) && isequal(size(L_tilde), size(L_tilde2))
                C = L;
            else
                C = feval2sym_NaNsingularity(symengine, 'symobj::subsasgn',L.s,R.s,new_size,assign_pos);
            end
        end

        function y = privToCell(x)
            y = arrayfun(@(t){t},x);
        end

        function y = normalizesym(x)
            %NORMALIZESYM Normalize an n-dim array sym to 9b semantics
            %   Y = NORMALIZESYM(X) checks if X is an n-dim array loaded
            %   from 9a mat file and converts it to a scalar ptr-to-array
            %   value used in 9b.
            sz = builtin('size',x);
            P = prod(sz);
            if P == 0
                y = reshape(sym([]),sz);
            elseif P == 1
                % shortcut for the most frequent case
                y = x;
            else
                y = reshape({x.s},sz);
                for i = 1:numel(y)
                    y{i} = evalin2sym(symengine, y{i});
                end
                y = cell2sym(y);
            end
        end

        function d = extractCreationTimeDigits(x)
            %extractCreationTimeDigits  Get the digits setting at creation time of
            %   x. If x is a simple variable, digits at that time is immaterial and
            %   this function may return [].
            d = [];
            if ~isempty(x.Digits)
                d = x.Digits;
                return
            end
            m = regexp(x.s,'^_symans_\[\[(\d+),','once','tokens');
            if ~isempty(m)
                d = str2double(m{1});
                x.Digits = d;
            end
        end

        function ezhelper(fcn,f,varargin)
            %EZHELPER Helper function for ezmesh, ezmeshc and ezsurf
            %   EZHELPER(FCN,F,...) turns sym object F into a function handle
            %   and calls the regular ez-function FCN.
            %   EZHELPER(FCN,X,Y,Z,...) turns sym objects X,Y,Z into a function handle
            %   and calls the regular ez-function FCN.
            if (length(varargin) >= 2) && (isa(varargin{1},'sym') || isa(varargin{2},'sym'))
                y = varargin{1};
                z = varargin{2};
                vars = unique([symvar(f) symvar(y) symvar(z)]);
                F = matlabFunction(f,'vars',vars);
                Y = matlabFunction(y,'vars',vars);
                Z = matlabFunction(z,'vars',vars);
                checkNoSyms(varargin(3:end));
                fcn(F,Y,Z,varargin{3:end});
                title(texlabel(['x = ' char(f) ', y = ' char(y) ', z = ' char(z)]));
            else
                F = matlabFunction(f);
                checkNoSyms(varargin);
                fcn(F,varargin{:});
                title(texlabel(char(f)));
            end
        end

        function createMathML(s,suggestions)
            %CREATEMATHML    Generate MathML presentation from sym object s.
            %   createMathML(s,suggestions) generates MathML code for the expression s.
            %                               The optional sym string suggestions is attached
            %                               to the MathML encoding as suggestions annotation.

            % get the correct number of digits to display for symfuns:
            useDigits = extractCreationTimeDigits(s);
            if ~isempty(useDigits)
                oldDigits = digits(useDigits);
                resetDigits = onCleanup(@() digits(oldDigits));
            end
            if nargin == 1
                suggestionsStr = '""';
            else
                suggestionsStr = suggestions.s;
            end
            s.mathmlOutput = feval2char(symengine, "symobj::generateMathML",s,suggestionsStr);
        end

        function str = getMathMLForSym(s)
            %MATHML    Return MathML presentation stored in sym object s.
            %   getMathMLForSym(s) retrieves MathML code for the expression s.
            if isempty(s.mathmlOutput)
                createMathML(s);
            end
            str = s.mathmlOutput;
        end

        % CompactDisplay for syms

        % Helper functions for Compact Display

        % Create a string array of the same dimension which
        % represents the symbolic object
        function stringArr = stringFromObj(X)
            % get the correct number of digits to display
            useDigits = extractCreationTimeDigits(X);
            if ~isempty(useDigits)
                oldDigits = digits(useDigits);
                resetDigits = onCleanup(@() digits(oldDigits));
            end

            allstrs = feval2char(symengine, "symobj::allstrs",X);
            stringArr = string(allstrs(2:end-1));
            if contains(allstrs,"#!")
                sz = size(X);
                stringArr = split(stringArr, '#!');
                stringArr(end) = [] ; % delete the empty string at the end
                stringArr = reshape(stringArr,sz);
            end
        end

        % Used for output inside cells and structs
        function displayRep = compactRepresentationForSingleLine(obj, displayConfiguration, width)
            import matlab.display.DimensionsAndClassNameRepresentation;
            import matlab.display.PlainTextRepresentation;
            % A scalar symbolic object is displayed if it fits into the available width.
            % If it is too long, it is truncated with ellipsis at the end.
            % A row vector is displayed if it fits into the available width.
            % If it is too long, it is displayed using the old default behavior displaying it by dimension and class name.
            % All other sym objects are displayed with the old default behavior displaying them by dimension and class name.
            if isscalar(obj)
                stringObj = stringFromObj(obj);
                [displayRep, ~] = widthConstrainedDataRepresentation(obj, displayConfiguration, width, "AllowTruncatedDisplayForScalar", true,...
                    "StringArray", stringObj);
            elseif isrow(obj)
                stringArr = stringFromObj(obj);
                displayRep = fullDataRepresentation(obj, displayConfiguration, "StringArray", stringArr);
            else
                displayRep = DimensionsAndClassNameRepresentation(obj, displayConfiguration);
            end
        end

        % Used for output inside tables.
        function displayRep = compactRepresentationForColumn(obj,displayConfiguration,width)
            import matlab.display.DimensionsAndClassNameRepresentation;
            import matlab.display.PlainTextRepresentation;
            if ismatrix(obj)
                if isscalar(privsubsref(obj,1,':'))
                    stringArr = stringFromObj(obj);
                    [displayRep, ~] = widthConstrainedDataRepresentation(obj, displayConfiguration, width, "AllowTruncatedDisplayForScalar", true,...
                        "StringArray", stringArr);
                else % we have a row vector if this is called from the Compact Display API
                    stringArr = stringFromObj(obj);
                    displayRep = fullDataRepresentation(obj, displayConfiguration, "StringArray", stringArr);
                end
            else
                displayRep = DimensionsAndClassNameRepresentation(obj, displayConfiguration);
            end
        end

        function str = getSuggestionsForSym(s,matlabVarNameStr,mupadOptionStr)
            %getSuggestionsForSym    Return JSON string presentation of Symbolic Suggestions for sym object s.
            %
            %   THIS FUNCTION IS FOR INTERNAL USE ONLY.
            %
            %   getSuggestionsForSym(s,matlabVarNameStr) computes Symbolic Suggestions for sym object s, where 
            %   matlabVarNameStr specifies the name of the MATLAB variable that holds the object s. Specifying
            %   matlabVarNameStr is required, e.g., for adding the right variable into generated MATLAB code
            %   and for identifying a symfun. Examples for matlabVarNameStr are "ans", "x", "f(x)".
            %   If matlabVarNameStr is the empty string "" then %{variable} is used as placeholder.
            %
            %   getSuggestionsForSym(s,matlabVarNameStr,mupadOptionStr) computes Symbolic Suggestions for sym
            %   object s, where mupadOptionStr is a string holding additional MuPAD options to be passed to
            %   symobj::suggestions, e.g., ', "menusAllowed" = TRUE'. See MuPAD function symobj::suggestions
            %   for details.
            %
            %   The function always returns a valid JSON string, e.g. "{}".

            % Do not error but fall back to default for 2nd argument.
            if nargin < 2
                matlabVarNameStr = "";
            else
                matlabVarNameStr = convertCharsToStrings(matlabVarNameStr);
                if ~isStringScalar(matlabVarNameStr)
                    matlabVarNameStr = "";
                elseif ~strcmp(matlabVarNameStr,"") && ...
                        isempty(regexp(matlabVarNameStr,"^[a-zA-Z][a-zA-Z0-9_]*(\(([a-zA-Z][a-zA-Z0-9_]*(\s*,\s*[a-zA-Z][a-zA-Z0-9_]*)*)?\))?$",'once'))
                    matlabVarNameStr = "";
                end
            end
            % Do not error but fall back to default for 3nd argument.
            if nargin < 3
                mupadOptionStr = "";
            else
                mupadOptionStr = convertCharsToStrings(mupadOptionStr);
                if ~isStringScalar(mupadOptionStr)
                    mupadOptionStr = "";
                end
            end
            % Determine symbolic variables that must be masked using sym('...').
            if feval2sym_NaNsingularity(symengine, "testtype", s, "Dom::SymbolicMatrix")
                % No relevant symbolic variables in symmatrix.
                varsReqSym = [];
            else
                % Determine variables in s that are not defined in workspace.
                varsReqSym = setdiff(string(symvar(s)), evalin('base', "string(who)"));
                % Consider the Moler variable x.
                if ~any(contains(varsReqSym, "x"))
                    try
                        x = evalin('base', "x");
                        if ~isa(x,'sym') || ~isSymType(x,"variable")
                            varsReqSym = [varsReqSym "x"];
                        end
                    catch
                        varsReqSym = [varsReqSym "x"];
                    end
                end
            end
            % Convert to string with MuPAD list representation.
            if isempty(varsReqSym)
                varsReqSym = "[]";
            else
                varsReqSym = replace(varsReqSym,'"','\"'); % e.g. "sym("Inf")"
                varsReqSym = "[""" + join(varsReqSym, """,""") + """]";
            end
            % Get Symbolic Suggestions from MuPAD.
            try
                str = feval2sym_NaNsingularity(symengine,"symobj::suggestions::get", s, ...
                    "table(""inputVarName""=""" + matlabVarNameStr ...
                    + """," ...
                    + """varsReqSym""="    + varsReqSym ...
                    + mupadOptionStr ...
                    + ")" ...
                    );
            catch
                % Return empty JSON string to indicate an error without breaking output.
                str = evalin2sym(symengine,'"{}"');
            end
        end

        function h = keyHash(x)
            cc = feval2char(symengine, "stdlib::hash", x);
            % MATLAB has special treatment for uint64(<digits>) and avoids
            % converting to double first; compare uint64(18446744073709551614)
            % and 18446744073709551614, uint64(ans)
            h = eval(['uint64(' cc ')']);
        end

        function tf = keyMatch(a,b)
            tf = isequaln(a,b);
        end

        function y = symengineSize(x)
            y = feval2double(symengine, 'symobj::size', x.s);
        end
    end    % hidden methods

end % classdef

%---------------   Subfunctions   -----------------

function S = tomupad(x)
%TOMUPAD    Convert input to sym reference string
% Called by sym constructor to take 'x' (just about anything) and return the reference string S.
% The reference string for simple variable names like 'x' or 'foo' is
% the variable name (with possible _Var appended). If 'a' is a size vector
% then a vector or matrix symbolic variable is constructed.
arguments
    x
end

if isa(x,'function_handle')
    x = funchandle2ref(x);
end

% avoid conversion to double for large integers that lose precision there:

if isa(x,'char')
    if ~isempty(x) && x(1)=='_'
        % answer from mupadmex _symansNNN
        S = x;
    else
        S = convertChar(x);
    end
elseif isa(x,'missing')
    S = numericToMuPAD(nan(size(x)));
elseif isnumeric(x) || islogical(x)
    S = numericToMuPAD(x);
elseif isa(x,'sym')
    xsym = privResolveArgs(x);
    x = xsym{1};
    S = evalin2charAns(symengine, x.s);  % make a new reference
elseif iscell(x)
    % undocumented syntax, still allowed for compatibility reasons
    xsym = cell2sym(x);
    S = evalin2charAns(symengine, xsym.s);  % make a new reference
else
    error(message('symbolic:sym:sym:errmsg7', class( x )))
end
end

function charVec = numericToMuPAD(x,flag)
%numericToMuPAD  Store a numeric array in MuPAD.
%    Stores numeric array x as an object in MuPAD and returns the MuPAD name of
%    that object.  The input 'flag' determines the form of the conversion.
if isscalar(x)
    S = "";
else
    S = strings(size(x));
end
if isinteger(x)
    if nargin == 2
        mustBeMember(flag, {'f', 'r', 'e', 'd', 'F', 'R', 'E', 'D'});
    end
    for k=1:numel(x)
        S(k) = symInt2Str(x(k));
    end
else
    if nargin < 2
        flag = 'r';
    end
    success = false;
    if isscalar(flag) && ischar(flag)
        if strcmpi(flag, 'f')
            for k = 1:numel(x)
                S(k) = symf(x(k));
            end
            success = true;
        elseif strcmpi(flag, 'r')
            for k = 1:numel(x)
                S(k) = symbolic.internal.symr(x(k));
            end
            success = true;
        elseif strcmpi(flag, 'e')
            for k=1:numel(x)
                S(k) = syme(x(k));
            end
            success = true;
        elseif strcmpi(flag, 'd')
            digs = digits;
            for k=1:numel(x)
                S(k) = symd(x(k),digs);
            end
            success = true;
        end
    end
    if ~success
        % use mustBeMember to error
        mustBeMember(flag, {'f', 'r', 'e', 'd', 'F', 'R', 'E', 'D'});
    end
end
charVec = stringArrayOfComponentsToReference(S);
end

function charVec = stringArrayOfComponentsToReference(Str)
% Create an array in MuPAD by treating the string array x as components.
% Returns the symans reference to the created object.
if isscalar(Str)
    charVec = evalin2charAns(symengine, Str);
else
    sz = size(Str);
    % MATLAB and MuPAD arrange components in opposite ways rowwise
    % and columnwise respectively store a MuPAD arrangement in y
    if ismatrix(Str)
        operator = "symobj::matrix";
    else
        operator = "symobj::array";
    end
    if isempty(Str)
        components = "[]";
    else
        y = columnsToRows(Str, sz);
        components = "[" + join(y, ",") + "]";
    end
    command = operator + "(" + components + "," + join(string(sz), ",") + ")";
    charVec = evalin2charAns(symengine, command);
end
end

function y = columnsToRows(x, sz)
% Re-order the string array x from columnwise to rowwise ordering
% For a matrix this is the transpose.
y = permute(x, numel(sz):-1:1);
y = y(:);
end

function S = funchandle2ref(x)
%FUNCHANDLE2REF convert func handle x to string form
str = char(x);
ind1 = find(str == '(',1);
if isempty(ind1) && nargin(x) >= 1
    % This is the case for most non-anonymous function handles,
    % e.g, @sin.
    error(message('symbolic:sym:sym:FunctionMustBeAnonymous'));
end
ind2 = find(str == ')',1);
inputs = str(ind1+1:ind2-1);
if ~isempty(inputs)
    S = regexp(inputs, ',', 'split');
    if any(strcmp(S, '~')) || any(strcmp(S,  'varargin'))
        error(message('symbolic:sym:sym:FunctionArgumentsMustBeVariables'));
    end
    S = cellfun(@sym, S, UniformOutput = false);
    S = x(S{:});
else
    S = sym(x());
end
end

function S = symf(x)
%SYMF   Hexadecimal symbolic representation of floating point numbers.
arguments
    x double
end
if imag(x) > 0
    S = ['(' symf(real(x)) ')+(' symf(imag(x)) ')*1i'];
elseif imag(x) < 0
    S = ['(' symf(real(x)) ')-(' symf(abs(imag(x))) ')*1i'];
elseif isinf(x)
    if x > 0
        S = 'Inf';
    else
        S = '-Inf';
    end
elseif isnan(x)
    S = 'NaN';
elseif x == 0
    S = '0';
else
    S = symbolic.internal.symfl(x);
end
end

function S = syme(x)
%SYME   Symbolic representation with error estimate.
arguments
    x double
end
if imag(x) > 0
    S = ['(' syme(real(x)) ')+(' syme(imag(x)) ')*1i'];
elseif imag(x) < 0
    S = ['(' syme(real(x)) ')-(' syme(abs(imag(x))) ')*1i'];
elseif isinf(x)
    if x > 0
        S = 'Inf';
    else
        S = '-Inf';
    end
elseif isnan(x)
    S = 'NaN';
else
    [S,err] = symbolic.internal.symr(x);
    if err ~= 0
        err = eval(tofloat(['(' symbolic.internal.symfl(x) ')-(' S ')'],'32'))/eps;
    end
    if err ~= 0
        [n,d] = rat(err,1.e-5);
        if n == 0 || abs(n) > 100000
            if abs(err/x) > 1e-3 % avoiding incompatibilities with old code
                [n,d] = rat(err/x,1e-3);
            else
                [n,d] = rat(err/x,abs(err/(2*x)));
            end
            if n >= 0
                S = [S '*(1+' int2str(n) '*eps/' int2str(d) ')'];
            else
                S = [S '*(1' int2str(n) '*eps/' int2str(d) ')'];
            end
            return
        end
        if n == 1
            S = [S '+eps'];
        elseif n == -1
            S = [S '-eps'];
        elseif n > 0
            S = [S '+' int2str(n) '*eps'];
        else
            S = [S int2str(n) '*eps'];
        end
        if d ~= 1
            S = [S '/' int2str(d)];
        end
    end
end
end

function S = symd(x,d)
%SYMD   Decimal symbolic representation.
arguments
    x double
    d
end
if imag(x) > 0
    S = ['(' symd(real(x),d) ')+(' symd(imag(x),d) ')*1i'];
elseif imag(x) < 0
    S = ['(' symd(real(x),d) ')-(' symd(abs(imag(x)),d) ')*1i'];
elseif isinf(x)
    if x > 0
        S = 'Inf';
    else
        S = '-Inf';
    end
elseif isnan(x)
    S = 'NaN';
else
    S = tofloat(symbolic.internal.symfl(x),int2str(d));
end
end

function B = isNumStr(x)
persistent pComplex;
if isempty(pComplex)
    pBlank = " *";
    pSign = "(?:[\- \+])*";                         % optional leading signs and blanks
    pPlus = "(?: *[\-\+][\- \+]*)";                 % mandatory plus or minus between real and imag including blanks
    pE = "(?:[Ee][\-\+]?\d+)?";                     % scientific notation group
    pI = "(?:i|j)";                                 % complex value i or j
    pSignedInt = pSign + "\d+";                     % integer with optional leading signs and blanks
    pRat  = "\d+" +      pBlank + "/" + pSignedInt; % rational with signed denominator
    pRatI = "\d+" + pI + pBlank + "/" + pSignedInt; % rational imag with signed denominator
    pIntOrFloat = "(?:\d+\.?\d*|\d*\.?\d+)" + pE;   % integer or float
    pIntOrFloatI = pIntOrFloat + pI;                % integer or float imag with optional leading signs and blanks
    pIntOrRatOrFloat  = "(?:" + pIntOrFloat  + "|" + pRat  + ")"; % integer, rational, or float real
    pIntOrRatOrFloatI = "(?:" + pIntOrFloatI + "|" + pRatI + ")"; % integer, rational, or float imag
    pComplex = "^" + pSign + ...                    % integer, rational, float, or complex
        "(?:" + pIntOrRatOrFloat  + ...
        "|" + pIntOrRatOrFloatI + ...
        "|" + pIntOrRatOrFloat  + pPlus + pIntOrRatOrFloatI + ...
        "|" + pIntOrRatOrFloatI + pPlus + pIntOrRatOrFloat  + ...
        ")" + pBlank + ...
        "$";
end
B = ~isempty(regexp(x,pComplex,'once')); % isequal(regexp(x, pComplex), 'once');
end

function s = convertChar(x)
% convertChar(X) converts the char vector to either a name
% that is a valid variable name in MuPAD or an expression.
% Also checks for MATLAB array syntax for backwards compatibility.
% Variable names are checked for overlap with MuPAD names and appends
% _Var to the name and returns a reference if the name is used by MuPAD.
x = strtrim(x);
if isvarname(x)
    s = convertName(x);
elseif ~isempty(regexp(x,"^[\-\+ ]*0[xb]",'ignorecase','once'))
    % Could be a hexadecimal or binary number.
    % We want to give the best error message in this case
    endings = "(u8|s8|u16|s16|u32|s32|u64|s64)";
    xparts = regexp(x,"(^[\+\- ]*)(0x[0-9a-f]+|0b[01]+)"+endings+"?$",'once','ignorecase','tokens');
    if isempty(xparts)
        if ~isempty(regexp(x,"^[\-\+ ]*0x",'ignorecase','once'))
            error(message('MATLAB:lang:InvalidHexNumber',''));
        else % 0b
            error(message('MATLAB:lang:InvalidBinaryNumber',''));
        end
    end

    if ~isempty(xparts{1})
        % Compute the sign of the number
        ysign = str2num([xparts{1} '1']); %#ok<ST2NM>
    else
        ysign = 1;
    end

    % Use str2num if a valid type format e.g. u8 etc. is given, to be
    % consistent to str2num.
    % Use also the following specification to be consistent:
    %     sym("-0b...s8") == -sym("0b...s8")
    % The same holds for str2num and str2sym where we have:
    %     str2num("-0b...s8") == -str2num("0b...s8")
    %     str2sym("-0b...s8") == -str2sym("0b...s8")
    if ~isempty(xparts{3})
        s = string(str2num([xparts{2} xparts{3}])); %#ok<ST2NM>
        if isempty(s)
            % Matched valid hex bin regex, failure due to truncation
            if ~isempty(regexp(x,"^[\-\+ ]*0x",'ignorecase','once'))
                error(message('MATLAB:lang:InvalidHexTruncation',''));
            else % 0b
                error(message('MATLAB:lang:InvalidBinaryTruncation',''));
            end
        end
        if ysign == -1
            if extractBefore(s,2) == "-"
                s = extractAfter(s,1);
            else
                s = "-" + s;
            end
        end
        s = char(s); % return char consistently
        return;
    end

    y = xparts{2};
    if lower(y(2)) == 'b'
        base = 2;
    else
        base = 16;
    end
    y = extractAfter(y,2);
    if ysign == -1
        y = ['-' y];
    end

    s = feval2char(symengine, "text2int", ['"' y '"'], string(base));
elseif isNumStr(x)
    % MuPAD does not support '1.' w/o trailing '0'
    x = regexprep(x,"\.([Eeij\+\- ])","\.0$1");
    if x(end) == '.'
        x = [x '0'];
    end
    s = evalin2charAns(symengine, x);
else
    ric = matlab.lang.correction.ReplaceIdentifierCorrection('sym', 'str2sym');
    error(ric,message('symbolic:sym:sym:ArgumentMustBeVarnameOrNumber'));
end
end

function s = charToMuPAD(x,a)
% Create a symbolic vector or matrix from the variable name x and size vector a.
arguments
    x {mustBeText}
    a double {mustBeVector}
end
if ~isvarname(strrep(x, '%d',''))
    error(message('symbolic:sym:SimpleVariable'));
end
a(a<0) = 0;
s = charToMuPADInternal(x,a);
end

function s = charToMuPADInternal(x,a)
arguments
    x
    a double {mustBeInteger}
end
if isscalar(a)
    s = createStringMatrixChecked(x,[a a]);
else
    s = createStringMatrixChecked(x,a);
end
end

function x = appendDefaultFormat(x, missingformats)
% Append the default matrix format string if needed
if missingformats < 0
    error(message('symbolic:sym:FormatTooLong'))
elseif missingformats > 0
    x = [x '%d' repmat('_%d', [1, missingformats-1])];
    % else the number of formats is right and we leave x as it is
end
end

function s = createStringMatrixChecked(x,a)
% Create a symbolic matrix from x and size a with total elements n
a = a(:).';
formats = length(find(x == '%'));
used = a(a>1);
if numel(used) < formats
    % We use also dimensions equal to 1 if many formats are given
    used = a;
elseif isempty(used)
    % For sym('x', 1), we create sym('x1')
    used = 1;
end
% add some %d if necessary
x = appendDefaultFormat(x, numel(used) - formats);
% check whether after plugging in the maximal indices, x is a valid
% variable name
if ~isvarname(sprintf(x, used))
    error(message('symbolic:sym:SimpleVariable'));
end
% special code for 2-dim input
if numel(used) == 2 && numel(a) == 2
    s = strings(used(1), used(2));
    for i=1:used(1)
        for j=1:used(2)
            s(i, j) = sprintf(x, i, j);
        end
    end
else
    s = strings(a);
    if isscalar(used)
        for k = 1:numel(s)
            s(k) = sprintf(x, k);
        end
    else
        ind = cell(1, numel(used));
        for k = 1:numel(s)
            [ind{:}] = ind2sub(used,k);
            s(k) = sprintf(x, ind{:});
        end
    end
end
s = stringArrayOfComponentsToReference(s);
end

function s = convertName(x)
%VARNAME2REF converts a variable name x into a MuPAD name s.
% The MuPAD name may have _Var appended to distinguish it from
% a predefined MuPAD symbol (like beta or D).
s = x;
if (~isempty(x) && ~isscalar(x)) || any(x=='DIOE')
    % ask MuPAD to check if the name is defined and internally use a different name
    xs = feval2sym_NaNsingularity(symengine, 'symobj::fixupVar',['"' x '"']);
    s = xs.s;
    xs.s = '';
end
end

function c = constantIdents
%CONSTANTIDENTS Return the mathematical constants
c = {'pi', 'eulergamma', 'catalan'};
end

function y = tofloat(x,d)
%TOFLOAT   Convert expression to vpa
%    Y = TOFLOAT(X,D) converts expression in string X to vpa with digits D.
y = feval2char(symengine, "symobj::float", x, d);
end

function s = privformat(x)
%PRIVFORMAT   Format array into MuPAD indexing string
%   S = PRIVFORMAT(X) turns X into a string S tailored for calling
%   MuPAD's indexing code.
assert(isnumeric(x));
if isscalar(x)
    s = sprintf('%d',double(x));
elseif ismatrix(x)
    s = privformatmatrix(x);
else
    s = privformatarray(x);
end
end

function s  = privformatmatrix(x)
%PRIVFORMATMATRIX  Format matrix object for indexing
str1 = sprintf('matrix(%d,%d,[',size(x,1),size(x,2));
x = double(x);
str2 = sprintf('%d,',x.');
% remove trailing comma without copy.
str2 = matlab.internal.math.viewColumns(str2,length(str2)-1);
s = [str1, str2, '])'];
end

function s  = privformatarray(x)
%PRIVFORMATARRAY  Format n-d array object for indexing
% In MuPAD, the order of the elements is different from MATLAB:
% elements only differing in the last index are close together,
% while in MATLAB, elements differing only in the first index are.
d = size(x);
str1 = sprintf('1..%d,',d);
x = permute(double(x), numel(d):-1:1);
str2 = sprintf('%d,',x(:));
% remove trailing comma without copy.
str2 = matlab.internal.math.viewColumns(str2,length(str2)-1);
s = ['array(', str1, '[', str2, '])'];
end

function checkNoSyms(args)
for i = 1:numel(args)
    if isa(args{i},'sym')
        error(message('symbolic:ezhelper:TooManySyms'));
    end
end
end

function X = logicalNaNIsFalse(A)
A = sym(A);
X = feval2logical(symengine, 'symobj::logicalNaNIsFalse', A.s);
end

function X = logicalNaNIsTrue(A)
A = sym(A);
X = feval2logical(symengine, 'symobj::logicalNaNIsTrue', A.s);
end
